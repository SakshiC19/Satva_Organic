import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../../config/firebase';
import { FiHeart, FiMinus, FiPlus, FiCheck } from 'react-icons/fi';
import { useCart } from '../../contexts/CartContext';
import Recommendations from '../../components/product/Recommendations';
import './ProductDetail.css';

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedBrand, setSelectedBrand] = useState('');
  const [selectedSize, setSelectedSize] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState('description');

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const productDoc = await getDoc(doc(db, 'products', id));
        if (productDoc.exists()) {
          const productData = { id: productDoc.id, ...productDoc.data() };
          setProduct(productData);
          
          if (productData.brands && productData.brands.length > 0) {
            setSelectedBrand(productData.brands[0]);
          }
          if (productData.packingSizes && productData.packingSizes.length > 0) {
            setSelectedSize(productData.packingSizes[0]);
          }
        } else {
          console.error('Product not found');
          navigate('/shop');
        }
      } catch (error) {
        console.error('Error fetching product:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
  }, [id, navigate]);

  const handleQuantityChange = (delta) => {
    const newQuantity = quantity + delta;
    if (newQuantity >= 1 && newQuantity <= (product?.stock || 999)) {
      setQuantity(newQuantity);
    }
  };

  const { addToCart, openCart } = useCart();

  const handleAddToCart = () => {
    if (!product) return;
    
    addToCart({
      ...product,
      selectedBrand,
      selectedSize,
      quantity
    });
    openCart();
  };

  const handleBuyNow = () => {
    handleAddToCart();
    navigate('/checkout');
  };

  if (loading) {
    return (
      <div className="product-detail-loading">
        <div className="spinner"></div>
        <p>Loading product...</p>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="product-detail-error">
        <h2>Product not found</h2>
        <Link to="/shop" className="btn btn-primary">Back to Shop</Link>
      </div>
    );
  }

  const productImages = product.images || [{ url: product.image }];
  const currentImage = productImages[selectedImage]?.url || productImages[selectedImage] || product.image;

  return (
    <div className="product-detail-page">
      <div className="container">
        <nav className="breadcrumb">
          <Link to="/">HOME</Link>
          <span className="separator">›</span>
          <Link to="/shop">{product.category?.toUpperCase() || 'PRODUCTS'}</Link>
          <span className="separator">›</span>
          <span className="current">{product.name?.toUpperCase()}</span>
        </nav>

        <div className="product-detail-main">
          <div className="product-images">
            <div className="main-image">
              <img src={currentImage} alt={product.name} />
              <button className="mobile-wishlist-btn" title="Add to Wishlist">
                <FiHeart />
              </button>
            </div>
            {productImages.length > 1 && (
              <div className="image-thumbnails">
                {productImages.map((img, index) => (
                  <div
                    key={index}
                    className={`thumbnail ${selectedImage === index ? 'active' : ''}`}
                    onClick={() => setSelectedImage(index)}
                  >
                    <img src={img.url || img} alt={`${product.name} ${index + 1}`} />
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="product-info">
            <div className="product-category-label">{product.category}</div>
            <h1 className="product-title">{product.name}</h1>

            <div className="product-meta">
              {product.brands && product.brands.length > 0 && (
                <div className="meta-item">
                  <span className="meta-label">Brands:</span>
                  <span className="meta-value">{product.brands.join(', ')}</span>
                </div>
              )}

              {/* SKU Removed */}
              <div className="meta-item">
                <span className="rating-stars">
                  {[...Array(5)].map((_, i) => (
                    <span key={i} className={i < Math.floor(product.rating || 4) ? 'star filled' : 'star'}>★</span>
                  ))}
                </span>
                <span className="rating-value" style={{ marginLeft: '8px', fontWeight: '600', color: '#4b5563' }}>
                  {product.rating ? product.rating.toFixed(1) : '4.0'}
                </span>
              </div>
            </div>

            <div className="product-price-group">
              <div className="product-price">
                <span className="current-price">₹{product.price}</span>
                {product.originalPrice && product.originalPrice > product.price && (
                  <>
                    <span className="original-price" style={{ textDecoration: 'line-through', color: '#999', marginLeft: '10px' }}>
                      ₹{product.originalPrice}
                    </span>
                    <span className="discount-badge" style={{ color: '#dc2626', marginLeft: '10px', fontWeight: '600' }}>
                      {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
                    </span>
                  </>
                )}
              </div>
              <div className="unit-price" style={{ fontSize: '14px', color: '#6b7280', marginTop: '-8px', marginBottom: '12px' }}>
                {(() => {
                   const size = selectedSize || (product.packingSizes && product.packingSizes[0]) || product.weight;
                   if (!size) return null;
                   const match = size.match(/(\d+(?:\.\d+)?)\s*([a-zA-Z]+)/);
                   if (match) {
                     const val = parseFloat(match[1]);
                     const unit = match[2].toLowerCase();
                     if (val > 0) {
                       let unitPrice = product.price / val;
                       let unitLabel = unit;
                       if (unit === 'g' || unit === 'gm') {
                         unitPrice = unitPrice * 1000;
                         unitLabel = 'kg';
                       } else if (unit === 'ml') {
                         unitPrice = unitPrice * 1000;
                         unitLabel = 'L';
                       }
                       return `(₹${unitPrice.toFixed(2)} / ${unitLabel})`;
                     }
                   }
                   return null;
                })()}
              </div>
            </div>

            <div className={`stock-status ${product.stock > 0 ? 'in-stock' : 'out-of-stock'}`}>
              {product.stock > 0 ? 'IN STOCK' : 'OUT OF STOCK'}
            </div>

            <div className="product-features" style={{ marginTop: '8px', marginBottom: '16px', borderTop: 'none', paddingTop: 0 }}>
              <div className="feature-item">
                <FiCheck className="feature-icon" />
                <span>Type: {product.productType || 'Organic'}</span>
              </div>
              <div className="feature-item">
                <FiCheck className={`feature-icon ${product.codAvailable !== false ? 'success' : 'error'}`} />
                <span>Cash on Delivery: {product.codAvailable !== false ? 'Available' : 'Not Available'}</span>
              </div>
              <div className="feature-item">
                <FiCheck className={`feature-icon ${product.refundPolicyAvailable ? 'success' : 'error'}`} />
                <span>Refund Policy: {product.refundPolicyAvailable ? 'Available' : 'Not Available'}</span>
              </div>
              {product.mfgDate && (
                <div className="feature-item">
                  <FiCheck className="feature-icon" />
                  <span>MFG: {product.mfgDate}</span>
                </div>
              )}
              {product.shelfLife && (
                <div className="feature-item">
                  <FiCheck className="feature-icon" />
                  <span>LIFE: {product.shelfLife}</span>
                </div>
              )}
            </div>

            <p className="product-description">{product.description}</p>

            {product.brands && product.brands.length > 0 && (
              <div className="product-option">
                <label className="option-label">Brands</label>
                <div className="option-buttons">
                  {product.brands.map((brand, index) => (
                    <button
                      key={index}
                      className={`option-btn ${selectedBrand === brand ? 'active' : ''}`}
                      onClick={() => setSelectedBrand(brand)}
                    >
                      {brand}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {(product.packingSizes && product.packingSizes.length > 0) || product.weight ? (
              <div className="product-option amount-option-container">
                <div className="amount-selection">
                  <label className="option-label">Weight</label>
                  <div className="option-buttons">
                    {(product.packingSizes && product.packingSizes.length > 0 
                      ? product.packingSizes 
                      : (product.weight ? [product.weight] : [])
                    ).map((size, index) => (
                      <button
                        key={index}
                        className={`option-btn ${selectedSize === size ? 'active' : ''}`}
                        onClick={() => setSelectedSize(size)}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="quantity-wishlist-group">
                  <div className="quantity-selector">
                    <button 
                      className="qty-btn" 
                      onClick={() => handleQuantityChange(-1)}
                      disabled={quantity <= 1}
                    >
                      <FiMinus />
                    </button>
                    <input 
                      type="number" 
                      value={quantity} 
                      readOnly 
                      className="qty-input"
                    />
                    <button 
                      className="qty-btn" 
                      onClick={() => handleQuantityChange(1)}
                      disabled={quantity >= (product.stock || 999)}
                    >
                      <FiPlus />
                    </button>
                  </div>
                  <button className="secondary-btn wishlist-inline-btn" title="Add to Wishlist">
                    <FiHeart />
                  </button>
                </div>
              </div>
            ) : (
              /* Fallback if no packing sizes, still show quantity */
              <div className="product-option amount-option-container">
                 <div className="amount-selection">
                    <label className="option-label">Quantity</label>
                 </div>
                 <div className="quantity-wishlist-group">
                   <div className="quantity-selector">
                    <button 
                      className="qty-btn" 
                      onClick={() => handleQuantityChange(-1)}
                      disabled={quantity <= 1}
                    >
                      <FiMinus />
                    </button>
                    <input 
                      type="number" 
                      value={quantity} 
                      readOnly 
                      className="qty-input"
                    />
                    <button 
                      className="qty-btn" 
                      onClick={() => handleQuantityChange(1)}
                      disabled={quantity >= (product.stock || 999)}
                    >
                      <FiPlus />
                    </button>
                  </div>
                  <button className="secondary-btn wishlist-inline-btn" title="Add to Wishlist">
                    <FiHeart />
                  </button>
                </div>
              </div>
            )}

            <div className="product-actions">
              <button 
                className="btn-add-to-cart"
                onClick={handleAddToCart}
                disabled={product.stock <= 0}
              >
                Add to cart
              </button>


            </div>


          </div>
        </div>

        <div className="product-tabs">
          <div className="tabs-header">
            <button
              className={`tab-btn ${activeTab === 'description' ? 'active' : ''}`}
              onClick={() => setActiveTab('description')}
            >
              Description
            </button>
            <button
              className={`tab-btn ${activeTab === 'additional' ? 'active' : ''}`}
              onClick={() => setActiveTab('additional')}
            >
              Additional Information
            </button>
            <button
              className={`tab-btn ${activeTab === 'reviews' ? 'active' : ''}`}
              onClick={() => setActiveTab('reviews')}
            >
              Reviews ({product.reviewCount || 0})
            </button>
          </div>

          <div className="tabs-content">
            {activeTab === 'description' && (
              <div className="tab-pane">
                <h3>Product Description</h3>
                <p>{product.description || 'No description available.'}</p>
                {product.longDescription && <p>{product.longDescription}</p>}
              </div>
            )}

            {activeTab === 'additional' && (
              <div className="tab-pane">
                <h3>Additional Information</h3>
                <table className="info-table">
                  <tbody>
                    <tr>
                      <th>Weight</th>
                      <td>{product.weight || 'N/A'}</td>
                    </tr>
                    <tr>
                      <th>Dimensions</th>
                      <td>{product.dimensions || 'N/A'}</td>
                    </tr>
                    <tr>
                      <th>Category</th>
                      <td>{product.category || 'N/A'}</td>
                    </tr>
                    {product.subcategory && (
                      <tr>
                        <th>Subcategory</th>
                        <td>{product.subcategory}</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            )}

            {activeTab === 'reviews' && (
              <div className="tab-pane">
                <h3>Customer Reviews</h3>
                <div className="review-form-container">
                  <h4>Write a Review</h4>
                  <form className="review-form" onSubmit={(e) => e.preventDefault()}>
                    <div className="form-group">
                      <label>Your Rating</label>
                      <div className="rating-input">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <span key={star} className="star-input">★</span>
                        ))}
                      </div>
                    </div>
                    <div className="form-group">
                      <label>Your Review</label>
                      <textarea placeholder="Write your review here..." rows="4"></textarea>
                    </div>
                    <button type="submit" className="btn-submit-review">Submit Review</button>
                  </form>
                </div>
                
                <div className="reviews-list">
                  <p>No reviews yet. Be the first to review this product!</p>
                </div>
              </div>
            )}
          </div>
        </div>

        <Recommendations 
          title="Similar Products" 
          category={product.category} 
          currentProductId={product.id} 
        />
      </div>
    </div>
  );
};

export default ProductDetail;
